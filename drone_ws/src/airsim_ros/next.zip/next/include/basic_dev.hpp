#ifndef _BASIC_DEV_HPP_
#define _BASIC_DEV_HPP_

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include "airsim_ros/VelCmd.h"
#include "airsim_ros/PoseCmd.h"
#include "airsim_ros/Takeoff.h"
#include "airsim_ros/Reset.h"
#include "airsim_ros/Land.h"
#include "airsim_ros/GPSYaw.h"
#include "airsim_ros/CirclePoses.h"
#include "nav_msgs/Odometry.h"
#include "geometry_msgs/Pose.h"
#include  "sensor_msgs/Imu.h"
#include <time.h>
#include <stdlib.h>
#include "Eigen/Dense"
#include "cv_bridge/cv_bridge.h"
#include "opencv2/opencv.hpp"
#include <ros/callback_queue.h>
#include <boost/thread/thread.hpp>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include<tf2/LinearMath/Matrix3x3.h>
#include "airsim_ros/AngleRateThrottle.h"

#include <tf2/LinearMath/Quaternion.h>

#include <string>
#include <iostream>
#include <fstream>
#include <math.h>
#include <cmath>
#include <random>
#include <nav_msgs/Path.h>
#include <std_msgs/String.h>
#include <geometry_msgs/Quaternion.h>
#include <geometry_msgs/PoseStamped.h>
#include <ros/console.h>
#include <tf/transform_datatypes.h>
#include <nav_msgs/Odometry.h>

#include "poly_traj.h"

using namespace std;
using namespace Eigen;

#endif
#
class BasicDev
{
public:
    //vins
    int flag =0;
    Vector3d _Vins_ini_position= Vector3d::Zero();
    Vector3d temp ;
    Vector3d vins_Pos = Vector3d::Zero();
    double vins_yaw = 0;
    Eigen::Quaterniond vins_q;
    geometry_msgs::Quaternion vins_orientation;
    // for planning
    double frequency = 100;
    int  _dev_order = 3;
    int _poly_num1D = 2 * _dev_order;
    double _Vel = 2;
    double _Acc = 1;
    double _angVel = 0.4;
    MatrixXd _polyCoeff;
    VectorXd _polyTime;
    geometry_msgs::Quaternion _orientation;
    double pi = 3.1415926535;
    Eigen::Quaterniond q;
    double yaw = 0;
    Vector3d _nowPos = Vector3d::Zero();
    ros::Time _lasttime = ros::Time::now();;
    ros::Time _nowtime = ros::Time::now();;
    Vector3d _lastPos = Vector3d::Zero();
    Vector3d _nowVel = Vector3d::Zero();
    Vector3d _pubVel = Vector3d::Zero();
    Vector3d _pubAcc = Vector3d::Zero();
    nav_msgs::Path realpath;
    nav_msgs::Path wpts;
    ros::Time _begin = ros::Time::now();
    Vector3d _est_eulerAngle;


    PolyTrajClass _PolyTraj;

    // 调用服务前需要定义特定的调用参数
    airsim_ros::Takeoff takeoff;

    // // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
    // airsim_ros::VelCmd velcmd;
    airsim_ros::VelCmd velcmd;
    // 使用publisher发布姿态指令需要定义 Posecmd , 并赋予相应的值后，将他publish（）出去
    airsim_ros::PoseCmd posecmd;


    //无人机信息通过如下命令订阅，当收到消息时自动回调对应的函数
    ros::Subscriber odom_suber;//状态真值
    ros::Subscriber vins_suber;
    ros::Subscriber wp_suber;//路径点

    //通过这两个服务可以调用模拟器中的无人机起飞和降落命令
    ros::ServiceClient takeoff_client;
    ros::Timer ctrl_timer1_;
    ros::Timer ctrl_timer2_;

    //通过这两个publisher实现对无人机的速度控制和姿态控制
    // ros::Publisher vel_publisher;
    ros::Publisher pose_publisher;
    ros::Publisher vel_publisher;
    ros::Publisher path_pub;
    ros::Publisher traj_pub;
    ros::Publisher traj_expect;

    void vel_rist();
    void yaw_control();

    void pose_cb(const geometry_msgs::Pose::ConstPtr& msg);
    void vins_cb(const nav_msgs::Odometry::ConstPtr& msg);
    void test_cb(const nav_msgs::Path::ConstPtr& wp);

    void trajGeneration(Eigen::MatrixXd path);
    void track_path(const ros::TimerEvent& event);
    // declare
    double getYawPoly( double vx, double vy );
    Vector3d getPosPoly( MatrixXd polyCoeff, int k, double t );
    Vector3d getVelPoly( MatrixXd polyCoeff, int k, double t );
    Vector3d getAccPoly( MatrixXd polyCoeff, int k, double t );
    VectorXd timeAllocation( MatrixXd Path);
    Eigen::Quaterniond ComputeAttitude(const Eigen::Quaterniond &est_q, const Eigen::Vector3d &des_acc, const double des_yaw);
    void visWayPointPath(Eigen::MatrixXd path);
    void visWayPointTraj( MatrixXd polyCoeff, VectorXd time);
    BasicDev(ros::NodeHandle *nh);
    ~BasicDev();

};





