// Useful customized headers
#include "basic_dev.hpp"
    
//Get the path points 

int main(int argc, char** argv)
{
    ros::init(argc, argv, "basic_dev");
    ros::NodeHandle nh;
    ros::Publisher path_pub = nh.advertise<nav_msgs::Path>("waypoints", 1, true);;

    vector<Vector3d> wp_list;
    wp_list.clear();

    Vector3d pt1(1,0,-1.51);
    
    Vector3d pt2(9,6,-1.26);

    Vector3d pt3(18.00,9.25,-1.259);
    Vector3d pt4(19.40,9.266,-1.259);
    Vector3d pt5(20.24,9.257,-1.259);
    Vector3d pt6(21.31,9.246,-1.259);

    Vector3d pt7(35,7,-9);

    Vector3d pt8(45.66,6.3057,-12.028);
    Vector3d pt9(47.03,5.287,-12.028);
    Vector3d pt10(48.07,4.793,-12.028);
    Vector3d pt11(49.09,4.3161,-12.028);

    Vector3d pt12(75,7,-5);

    Vector3d pt13(86.146,8.16,-1.379);
    Vector3d pt14(87.5367,8.668,-1.379);
    Vector3d pt15(88.51,9.024,-1.379);

    Vector3d pt16(94,15,-7);

    Vector3d pt17(99.013,22.1736,-10.018);
    Vector3d pt18(99.98,22.95,-10.018);
    Vector3d pt19(101.76,23.72,-10.018);
    
    
    
    wp_list.push_back(pt1);
    
    wp_list.push_back(pt2);

    wp_list.push_back(pt3);
    wp_list.push_back(pt4);
    wp_list.push_back(pt5);
    wp_list.push_back(pt6);

    wp_list.push_back(pt7);

    wp_list.push_back(pt8);
    wp_list.push_back(pt9);
    wp_list.push_back(pt10);
    wp_list.push_back(pt11);
    
    wp_list.push_back(pt12);

    wp_list.push_back(pt13);
    wp_list.push_back(pt14);
    wp_list.push_back(pt15);
    
    wp_list.push_back(pt16);

    wp_list.push_back(pt17);
    wp_list.push_back(pt18);
    wp_list.push_back(pt19);
    // Vector3d pt1(0,0,-2);
    
    // Vector3d pt2(0,0,-4);

    // Vector3d pt3(0,0,-6);
    // Vector3d pt4(0,0,-8);
    // Vector3d pt5(0,0,-10);
    // Vector3d pt6(0,0,-12);

    
    
    
    
    // wp_list.push_back(pt1);
    
    // wp_list.push_back(pt2);

    // wp_list.push_back(pt3);
    // wp_list.push_back(pt4);
    // wp_list.push_back(pt5);
    // wp_list.push_back(pt6);



    nav_msgs::Path points;
    geometry_msgs::PoseStamped pt;
    for(int k = 0; k < wp_list.size()  ; k++){
        pt.pose.position.x = wp_list[k](0);
        pt.pose.position.y = wp_list[k](1);
        pt.pose.position.z = wp_list[k](2);
        points.poses.push_back(pt);
    }
    ros::Duration(2.5).sleep();
    
    while(ros::ok)
    {
        path_pub.publish(points);
    }

    ros::spin();

}
