#ifndef _BASIC_DEV_CPP_
#define _BASIC_DEV_CPP_

#include "basic_dev.hpp"
  


BasicDev::BasicDev(ros::NodeHandle *nh)
{  

    _PolyTraj= PolyTrajClass(_dev_order, _Vel, _Acc);

    takeoff.request.waitOnLastTask = 1;

    // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
    velcmd.twist.angular.z = 0;//z方向角速度(yaw, deg)
    velcmd.twist.linear.x = 0; //x方向线速度(m/s)
    velcmd.twist.linear.y = 0;//y方向线速度(m/s)
    velcmd.twist.linear.z = 0; //z方向线速度(m/s)


    //无人机信息通过如下命令订阅，当收到消息时自动回调对应的函数
    odom_suber = nh->subscribe<geometry_msgs::Pose>("/airsim_node/drone_1/debug/pose_gt", 1, std::bind(&BasicDev::pose_cb, this, std::placeholders::_1));//状态真值，用于赛道一
    vins_suber = nh->subscribe<nav_msgs::Odometry>("vins_estimator/imu_propagate", 1, &BasicDev::vins_cb ,this);//状态真值，用于赛道一
    wp_suber = nh->subscribe<nav_msgs::Path>("waypoints", 1, &BasicDev::test_cb ,this);
    path_pub = nh->advertise<nav_msgs::Path>("path",1, true);
    traj_pub = nh->advertise<nav_msgs::Path>("traj",1, true);
    traj_expect = nh->advertise<nav_msgs::Path>("traj_expect",1, true);
    //通过publisher实现对无人机的速度控制和姿态控制和角速度控制
    vel_publisher = nh->advertise<airsim_ros::VelCmd>("airsim_node/drone_1/vel_cmd_body_frame", 1);
    pose_publisher = nh->advertise<airsim_ros::PoseCmd>("airsim_node/drone_1/pose_cmd_body_frame", 1);
    //通过这两个服务可以调用模拟器中的无人机起飞和降落命令
    takeoff_client = nh->serviceClient<airsim_ros::Takeoff>("/airsim_node/drone_1/takeoff");
    takeoff_client.call(takeoff);
    ros::Duration(3).sleep();
    ros::spinOnce();
    // ctrl_timer1_ = nh->createTimer(ros::Duration(1.0/frequency), &BasicDev::test_cb, this, false, true);
    ctrl_timer2_ = nh->createTimer(ros::Duration(1.0/frequency), &BasicDev::track_path, this, false, true);
}
void BasicDev::pose_cb(const geometry_msgs::Pose::ConstPtr& msg)
{
    _nowPos(0) = msg->position.x;
    _nowPos(1) = msg->position.y;
    _nowPos(2) = msg->position.z;

    _nowtime = ros::Time::now();
    double deltaT = (_nowtime-_lasttime).toSec();
    _nowVel = (_nowPos-_lastPos)/deltaT;
    // cout<<"_nowVel:"<<_nowVel<<endl;
    _lastPos = _nowPos;
    _lasttime = _nowtime;
    yaw=tf::getYaw(msg->orientation);
    q = Eigen::Quaterniond(Eigen::Vector4d (msg->orientation.x, 
                               msg->orientation.y, msg->orientation.z,msg->orientation.w));
    _orientation= msg->orientation;
    tf2::Quaternion tf_q(q.x(),q.y(),q.z(),q.w());
    tf2::Matrix3x3(tf_q).getRPY(_est_eulerAngle(0),_est_eulerAngle(1),_est_eulerAngle(2));
    // _est_eulerAngle=q.matrix().eulerAngles(2,1,0);
    // cout<<"eulerAngle"<<_est_eulerAngle<<"yaw:"<<yaw<<endl;
    
}

void BasicDev::vins_cb(const nav_msgs::Odometry::ConstPtr& msg)
{
    // cout<<"getvins"<<endl;
    // if(flag == 0)
    // {
    //     _Vins_ini_position(0) = msg->pose.pose.position.x;
    //     _Vins_ini_position(1) = -msg->pose.pose.position.y;
    //     _Vins_ini_position(2) = -msg->pose.pose.position.z;
    //     flag = 1;
    //     return;
    // }
    
    temp(0) = msg->pose.pose.position.x;
    temp(1) = -msg->pose.pose.position.y;
    temp(2) = -msg->pose.pose.position.z;
    vins_Pos = temp - _Vins_ini_position;
    cout<<"real_pose"<<_nowPos<<"vinspos:"<<vins_Pos;
    vins_yaw=-tf::getYaw(msg->pose.pose.orientation);
    vins_q = Eigen::Quaterniond(msg->pose.pose.orientation.w, msg->pose.pose.orientation.x, 
                               msg->pose.pose.orientation.y, msg->pose.pose.orientation.z);
    vins_orientation= msg->pose.pose.orientation;
}

void BasicDev::test_cb(const nav_msgs::Path::ConstPtr& wp)
{  

    //判断是否需要重新规划
    if(wp->poses.size()==0)
    {
        cout<<"lenth == 0"<<endl;
        return;
    }
    if(wpts.poses.size() != wp->poses.size())
    {

    }
    else
    {
        int flag = 0;
        for(int i = 0;i<wp->poses.size();i++)
        {
            if(wpts.poses[i].pose.position != wp->poses[i].pose.position)
            {
                flag = 1;
                break;
            }
        }
        if(flag == 0)
        {
            return;
        }
    }
    wpts.poses = wp->poses;

    cout<<"get planning points"<<endl;
    vector<Vector3d> wp_list;
    wp_list.clear();

    for (int k = 0; k < (int)wp->poses.size(); k++)
    {
        Vector3d pt( wp->poses[k].pose.position.x, wp->poses[k].pose.position.y, wp->poses[k].pose.position.z);
        wp_list.push_back(pt);
        //cout<<pt;
    }

    MatrixXd waypoints(wp_list.size() + 1, 3);
    waypoints.row(0) = _nowPos;
    
    for(int k = 0; k < (int)wp_list.size(); k++)
        waypoints.row(k+1) = wp_list[k];

    //Trajectory generation: use minimum snap trajectory generation method
    //waypoints is the result of path planning (Manual in this homework)
    trajGeneration(waypoints); 
    
}

BasicDev::~BasicDev()
{
}

Eigen::Quaterniond BasicDev::ComputeAttitude(const Eigen::Quaterniond &est_q, const Eigen::Vector3d &des_acc, const double des_yaw)
{
    Eigen::Quaterniond q_head = Eigen::Quaterniond(Eigen::AngleAxisd(des_yaw, Eigen::Vector3d::UnitZ()));

    // Compute desired orientation
    const Eigen::Vector3d x_C = q_head * Eigen::Vector3d::UnitX();
    const Eigen::Vector3d y_C = q_head * Eigen::Vector3d::UnitY();

    Eigen::Vector3d z_B;
    if (std::fabs(des_acc.norm()) < 1e-3) {
        z_B = est_q * Eigen::Vector3d::UnitZ();
    } else {
        z_B = des_acc.normalized();
    }
    Eigen::Vector3d x_B = y_C.cross(z_B).normalized();
    // Eigen::Vector3d x_B = computeRobustBodyXAxis(x_B_org, x_C, y_C, est_q);
    Eigen::Vector3d y_B = (z_B.cross(x_B)).normalized();
    Eigen::Matrix3d R_WB((Eigen::Matrix3d() << x_B, y_B, z_B).finished());
    return Eigen::Quaterniond(R_WB);
}

void BasicDev::trajGeneration(Eigen::MatrixXd path)
{
    
    Eigen::Vector3d start_vel=_pubVel;
    Eigen::Vector3d end_vel(0,0,0);
    Eigen::Vector3d start_acc=_pubAcc;
    Eigen::Vector3d end_acc(0,0,0);
    start_vel = _nowVel;

    // give an arbitraty time allocation, all set all durations as 1 in the commented function.
    _PolyTraj.AllocateTime(path, _polyTime);

    // generate a minimum-snap piecewise monomial polynomial-based trajectory
    _PolyTraj.TrajGenerate(path, start_vel,end_vel, start_acc,end_acc, _polyTime);
    _polyCoeff = _PolyTraj.poly_coeff_mat_;
    //cout<<"path"<<path;
    visWayPointPath(path);
    visWayPointTraj(_polyCoeff, _polyTime);

    _begin = ros::Time::now();
}

void BasicDev::track_path(const ros::TimerEvent& event)
{
    realpath.header.frame_id="odom";
    ros::Time begin = _begin;
    if(_polyTime.size()==0)
    {
        cout<<"cant planning"<<endl;
        return;
    }
    MatrixXd polyCoeff(_polyCoeff);
    VectorXd time(_polyTime);

    Vector3d pos = _nowPos;
    Vector3d gravity(0,0,9.8);
    Vector3d vel;
    Vector3d acc;
    //pid
    Vector3d deltapos_sum = Vector3d::Zero();
    Vector3d deltapos_pre = Vector3d::Zero();
    Eigen::Quaterniond q_next;
    double Kp = 4.4,Ki = 0,Kd = 0,Kp_z = 5.0,Ki_z = 0,Kd_z = 0;
    double Kp_ang= 0.005;
    double Kpa = 0.005;


        ros::Duration timeFbegin = ros::Time::now() - begin;
        double t1 = timeFbegin.toSec();
        int i = 0;
        while(t1>=0 && (t1 > time(i)))
        {
            t1 =t1 -time(i);
            i =i+1;
            if(i == time.size() )
            {
                return;
            }
        }

        geometry_msgs::PoseStamped pt;
        


        vel = getVelPoly(polyCoeff, i, t1);
        _pubVel = vel;
        pos = getPosPoly(polyCoeff, i, t1);
        acc = getAccPoly(polyCoeff, i, t1);
        _pubAcc = acc;
        //yaw
        double theta=getYawPoly( vel(0), vel(1) );
        double delta_theta=fmod((theta - yaw + pi),(2 * pi)) - pi;
        cout<<"theta:"<<theta<<endl;
        double vel_yaw = Kp_ang * delta_theta;

        //pid
        Vector3d deltapos = pos - _nowPos;
        cout<<"deltapos:"<<deltapos<<endl;

        Vector3d velout = vel + Kp*deltapos ;
        velout(2) =  vel(2)+ Kp_z*deltapos(2) ; 

        Vector3d des_acc = acc + Kpa*deltapos - gravity;
        // cout<<"acc:"<<des_acc<<endl;
        //pose
        q_next = ComputeAttitude(q, des_acc, 0);
        Eigen::Vector3d eulerAngle=q_next.matrix().eulerAngles(2,1,0);





        pt.pose.position.x = _nowPos(0);
        pt.pose.position.y = _nowPos(1);
        pt.pose.position.z = _nowPos(2);
        pt.pose.orientation = _orientation;

        // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
        velcmd.twist.angular.z = vel_yaw;//z方向角速度(yaw, deg)
        velcmd.twist.linear.x = velout(0); //x方向线速度(m/s)
        velcmd.twist.linear.y = velout(1);//y方向线速度(m/s)
        velcmd.twist.linear.z = velout(2); //z方向线速度(m/s)
        BasicDev::vel_rist();
        // if(abs(_nowVel(0)) < 0.1 && abs(_nowVel(1)) < 0.1 && abs(delta_theta) > 1 &&
        // abs(acc(0)) < 0.1 && abs(acc(1)) < 0.1 )
        // {
        //     // velcmd.twist.angular.z = 10*vel_yaw;
        //     // // vel_publisher.publish(velcmd);
        //     // // cout<<"vel:"<<velcmd<<endl;
        //     // // posecmd.roll = eulerAngle(0); //x方向姿态(rad)
        //     posecmd.yaw = theta;//z方向姿态(rad)
        //     posecmd.throttle = 0.6;//油门， （0.0-1.0）
        //     cout<<"posecmd:"<<posecmd<<endl;
        //     pose_publisher.publish(posecmd);
        // }
        // else
        // {
        //     vel_publisher.publish(velcmd);
        //     cout<<"vel:"<<velcmd<<endl;
        // }
        vel_publisher.publish(velcmd);
        cout<<"vel:"<<velcmd<<endl;

        // // 使用publisher发布速度指令需要定义 Velcmd , 并赋予相应的值后，将他publish（）出去
        // // 使用publisher发布姿态指令需要定义 Posecmd , 并赋予相应的值后，将他publish（）出去
        // posecmd.roll = eulerAngle(0); //x方向姿态(rad)
        // posecmd.pitch = eulerAngle(1);//y方向姿态(rad)
        // posecmd.yaw = eulerAngle(2);//z方向姿态(rad)
        // posecmd.throttle = 0.8;//油门， （0.0-1.0）
        // cout<<"posecmd:"<<posecmd<<endl;
        // pose_publisher.publish(posecmd);
        
        pt.header.frame_id="odom";
        realpath.poses.push_back(pt);
        traj_pub.publish(realpath);
    
}

void BasicDev::visWayPointTraj( MatrixXd polyCoeff, VectorXd time)
{
    nav_msgs::Path points;
    points.header.frame_id="odom";
    Vector3d pos;
    for(int i = 0; i < time.size(); i++ )
    {   
        for (double t = 0.0; t < time(i); t += 0.01)
        {
            geometry_msgs::PoseStamped pt;
            pos = getPosPoly(polyCoeff, i, t);
            pt.pose.position.x = pos(0);
            pt.pose.position.y = pos(1);
            pt.pose.position.z = pos(2);
            pt.header.frame_id="odom";
            points.poses.push_back(pt);

        }
    }
    traj_expect.publish(points);

}

void BasicDev::visWayPointPath(Eigen::MatrixXd path)
{
    nav_msgs::Path points;
    points.header.frame_id="odom";
    for(int i = 0;i<path.rows();i++)
        {
            geometry_msgs::PoseStamped pt;
            pt.pose.position.x = path(i,0);
            pt.pose.position.y = path(i,1);
            pt.pose.position.z = path(i,2);
            pt.header.frame_id="odom";
            points.poses.push_back(pt);
        }
    path_pub.publish(points);
}

Vector3d BasicDev::getAccPoly( MatrixXd polyCoeff, int k, double t )
{
    Vector3d ret;

    for ( int dim = 0; dim < 3; dim++ )
    {
        VectorXd coeff = (polyCoeff.row(k)).segment( dim * _poly_num1D, _poly_num1D );
        VectorXd time  = VectorXd::Zero( _poly_num1D );
//        for(int j = _poly_num1D-1; j >= 0; j--)

        for(int j = 0; j < _poly_num1D; j ++)
          if(j<2)
              time(j) = 0;
          else
              time(j) = j*(j-1)*pow(t, j-2);

        ret(dim) = coeff.dot(time);
        //cout << "dim:" << dim << " coeff:" << coeff << endl;
    }

    return ret;
}

double BasicDev::getYawPoly( double vx, double vy )
{
    double vxy = std::sqrt(vx*vx + vy*vy);
    double theta;
    double sin_theta = vy/vxy;
    double cos_theta = vx/vxy;
    if(sin_theta >= 0)
    {
        theta = std::acos(sin_theta);
    }
    else if(sin_theta < 0)
    {
        theta = - std::asin(sin_theta);
    }


    return theta;
}
Vector3d BasicDev::getVelPoly( MatrixXd polyCoeff, int k, double t )
{
    Vector3d ret;

    for ( int dim = 0; dim < 3; dim++ )
    {
        VectorXd coeff = (polyCoeff.row(k)).segment( dim * _poly_num1D, _poly_num1D );
        VectorXd time  = VectorXd::Zero( _poly_num1D );
//        for(int j = _poly_num1D-1; j >= 0; j--)

        for(int j = 0; j < _poly_num1D; j ++)
          if(j==0)
              time(j) = 0;
          else
              time(j) = j*pow(t, j-1);

        ret(dim) = coeff.dot(time);
        //cout << "dim:" << dim << " coeff:" << coeff << endl;
    }

    return ret;
}

Vector3d BasicDev::getPosPoly( MatrixXd polyCoeff, int k, double t )
{
    Vector3d ret;

    for ( int dim = 0; dim < 3; dim++ )
    {
        VectorXd coeff = (polyCoeff.row(k)).segment( dim * _poly_num1D, _poly_num1D );
        VectorXd time  = VectorXd::Zero( _poly_num1D );
//        for(int j = _poly_num1D-1; j >= 0; j--)

        for(int j = 0; j < _poly_num1D; j ++)
          if(j==0)
              time(j) = 1.0;
          else
              time(j) = pow(t, j);

        ret(dim) = coeff.dot(time);
        //cout << "dim:" << dim << " coeff:" << coeff << endl;
    }

    return ret;
}

void BasicDev::vel_rist()
{
    // if(velcmd.twist.linear.x > _Vel)velcmd.twist.linear.x = _Vel; //x方向线速度(m/s)
    // if(velcmd.twist.linear.x < -_Vel)velcmd.twist.linear.x = -_Vel; //x方向线速度(m/s)
    // if(velcmd.twist.linear.y > _Vel)velcmd.twist.linear.y = _Vel; //x方向线速度(m/s)
    // if(velcmd.twist.linear.y < -_Vel)velcmd.twist.linear.y = -_Vel; //x方向线速度(m/s)
    // if(velcmd.twist.linear.z > _Vel)velcmd.twist.linear.z = _Vel; //x方向线速度(m/s)
    // if(velcmd.twist.linear.z < -_Vel)velcmd.twist.linear.z = -_Vel; //x方向线速度(m/s)

    if(velcmd.twist.angular.z > _angVel)velcmd.twist.angular.z = _angVel;
    if(velcmd.twist.angular.z < -_angVel)velcmd.twist.angular.z = -_angVel;
}
VectorXd BasicDev::timeAllocation( MatrixXd Path)
{ 
    VectorXd time(Path.rows() - 1);
    
    /*

    STEP 1: Learn the "trapezoidal velocity" of "TIme Allocation" in L5, then finish this timeAllocation function

    variable declaration: _Vel, _Acc: _Vel = 1.0, _Acc = 1.0 in this homework, you can change these in the test.launch

    You need to return a variable "time" contains time allocation, which's type is VectorXd

    The time allocation is many relative timeline but not one common timeline

    */
    
    double t_slope = _Vel / _Acc;
    double max_s_triangle =  t_slope * _Vel;
    //std::cout <<"Path: "<< Path << std::endl;

    time = VectorXd::Ones(Path.rows() - 1);
    for(int k = 0;k < Path.rows()-1;k++){
        Vector3d p1_2 = Path.row(k) - Path.row(k+1);
        double s = std::sqrt(p1_2.dot(p1_2));

        if(s <= max_s_triangle){
            time(k) = 2.0 * s / _Acc;
        }
        else{
            time(k) = (s - max_s_triangle) / _Vel + t_slope;
        }
        // time(k) = s / _Vel;
    }
    //std::cout <<"time: "<< time << std::endl;
    return time;
}
#endif