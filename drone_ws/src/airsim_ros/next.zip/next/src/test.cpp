
// Useful customized headers
#include "basic_dev.hpp"


    

    
//Get the path points 




int main(int argc, char** argv)
{
    ros::init(argc, argv, "basic_dev");
    ros::NodeHandle nh;

    BasicDev go(&nh);
    ros::spin();

}





