#pragma once


#define OPENCV4

// #ifdef OPENCV4 

// #define cv::COLOR_GRAY2RGB                 cv::COLOR_GRAY2RGB
// #define cv::COLOR_GRAY2BGR                 cv::COLOR_GRAY2BGR
// #define cv::COLOR_BGR2GRAY                 cv::COLOR_BGR2GRAY
// #define cv::LINE_AA                       cv::LINE_AA
// #define cv::CALIB_CB_ADAPTIVE_THRESH cv::CALIB_CB_ADAPTIVE_THRESH
// #define cv::CALIB_CB_NORMALIZE_IMAGE cv::CALIB_CB_NORMALIZE_IMAGE
// #define cv::CALIB_CB_FILTER_QUADS    cv::CALIB_CB_FILTER_QUADS
// #define cv::CALIB_CB_FAST_CHECK      cv::CALIB_CB_FAST_CHECK
// #define cv::CALIB_CB_ADAPTIVE_THRESH cv::CALIB_CB_ADAPTIVE_THRESH
// #define cv::IMREAD_UNCHANGED     cv::IMREAD_UNCHANGED
// #define CV_ADAPTIVE_THRESH_MEAN_C   cv::ADAPTIVE_THRESH_MEAN_C


// #endif