#include "imu_filter.h"

void ImuFilter::process(Eigen::Vector3d& acc, Eigen::Vector3d& gyro) {
  
}